<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Todo los proyectos</title>
</head>
<body>
<h1>Lista de Proyectos</h1>
<a href="/posts/crear">Crear nuevo proyecto</a><br><br>
<?php if($proyectos->isEmpty()): ?>
        <p>No hay proyectos disponibles.</p>
    <?php else: ?>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Fecha de Inicio</th>
                    <th>Estado</th>
                    <th>Responsable</th>
                    <th>Monto</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($proyecto->id); ?></td>
                        <td><?php echo e($proyecto->nombre); ?></td>
                        <td><?php echo e($proyecto->fechainicio); ?></td>
                        <td><?php echo e($proyecto->estado ? 'Activo' : 'Inactivo'); ?></td>
                        <td><?php echo e($proyecto->responsable); ?></td>
                        <td>$<?php echo e(number_format($proyecto->monto, 2)); ?></td>
                        <td><a href="/posts/<?php echo e($proyecto->id); ?>">Ver</a></td>
                    <td><a href="/posts/<?php echo e($proyecto->id); ?>/edit">Modificar</a></td>
                    <td><form action="/posts/<?php echo e($proyecto->id); ?>" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit">Eliminar Proyecto</button>
                        </form>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\Oscar\dwi-70-24\EnClases\resources\views/ViewTodo.blade.php ENDPATH**/ ?>