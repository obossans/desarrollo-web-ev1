<!DOCTYPE html>
<html>
<head>
    <title>Valor UF</title>
</head>
<body>
    <h1>Valor de la UF</h1>
    <?php if(isset($ufValue)): ?>
        <p>El valor de la UF hoy es: <?php echo e($ufValue); ?></p>
    <?php else: ?>
        <p>No se pudo obtener el valor de la UF.</p>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\Oscar\dwi-70-24\EnClases\resources\views/ufView.blade.php ENDPATH**/ ?>