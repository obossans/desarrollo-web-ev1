<div>
    <!-- It is not the man who has too little, but the man who craves more, that is poor. - Seneca -->
</div>
<?php /**PATH C:\Users\Oscar\dwi-70-24\EnClases\resources\views/ProyectoView.blade.php ENDPATH**/ ?>