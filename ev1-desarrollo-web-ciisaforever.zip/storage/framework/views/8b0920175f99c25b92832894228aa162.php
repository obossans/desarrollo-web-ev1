<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver detalle de un Proyecto</title>
</head>
<body>
    <h1>Detalles del Proyecto</h1>

    <?php if($proyecto): ?>
        <ul>
            <li><strong>ID:</strong> <?php echo e($proyecto->id); ?></li>
            <li><strong>Nombre:</strong> <?php echo e($proyecto->nombre); ?></li>
            <li><strong>Fecha de Inicio:</strong> <?php echo e($proyecto->fechainicio); ?></li>
            <li><strong>Estado:</strong> <?php echo e($proyecto->estado ? 'Activo' : 'Inactivo'); ?></li>
            <li><strong>Responsable:</strong> <?php echo e($proyecto->responsable); ?></li>
            <li><strong>Monto:</strong> $<?php echo e(number_format($proyecto->monto, 2)); ?></li>
        </ul>
    <?php else: ?>
        <p>El proyecto que buscas no existe.</p>
    <?php endif; ?>

    <a href="<?php echo e(url('/posts')); ?>">Volver a la lista de proyectos</a>
</body>
</html><?php /**PATH C:\Users\Oscar\dwi-70-24\EnClases\resources\views/ViewUno.blade.php ENDPATH**/ ?>