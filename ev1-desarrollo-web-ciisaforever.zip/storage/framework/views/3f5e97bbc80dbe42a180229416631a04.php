<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Post</title>
</head>
<body>
    <h1>Modificar Proyecto</h1>
    <form action="/posts/<?php echo e($proyecto->id); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php echo method_field('PUT'); ?> 
        <br><br>
        <label>
            Nombre:
            <input type="text" name="nombre" value="<?php echo e($proyecto->nombre); ?>">
        </label>
        <br><br>
        <label>
            Fecha de Inicio:
            <input type="text" name="fechainicio" value="<?php echo e($proyecto->fechainicio); ?>">
        </label>
        <br><br>
        <label for="estado">Estado:</label>
        <select name="estado" id="estado">
                    <option value="1" <?php echo e(($proyecto->estado) == 1 ? 'selected' : ''); ?>>Activo</option>
                    <option value="0" <?php echo e(($proyecto->estado) == 0 ? 'selected' : ''); ?>>Inactivo</option>
                </select>
        <br><br>
        <label>
            Responsable:
            <input type="text" name="responsable" value="<?php echo e($proyecto->responsable); ?>">
        </label>
        <br><br>
        <label>
            Monto:
            <input type="number" name="monto" value="<?php echo e($proyecto->monto); ?>">
        </label>
        <br><br>
        <button type="submit">Editar Proyecto</button>
    </form>
</body>
</html><?php /**PATH C:\Users\Oscar\dwi-70-24\EnClases\resources\views/ViewModificar.blade.php ENDPATH**/ ?>